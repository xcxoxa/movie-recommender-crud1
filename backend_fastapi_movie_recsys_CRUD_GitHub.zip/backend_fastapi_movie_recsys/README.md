# FastAPI Movie Recommender CRUD

기존 프로젝트명과 추천 기능을 유지하면서 회원, 영화, 평점 CRUD와 통계 조회를 추가한 백엔드입니다.

## 실행 준비

```powershell
cd C:\bangminjung\04_react_fastapi_mysql\backend_fastapi_movie_recsys
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

`.env`의 DB 접속 정보를 자신의 MySQL 환경에 맞게 확인합니다.

## 데이터베이스 초기화

MySQL Workbench에서 `sql/schema.sql`을 실행한 다음 `sql/seed.sql`을 실행합니다.
`seed.sql`은 기존 데이터를 초기화하므로 실습용 DB에서만 사용합니다.

## 백엔드 실행

```powershell
cd C:\bangminjung\04_react_fastapi_mysql\backend_fastapi_movie_recsys
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

- API 상태: http://127.0.0.1:8000/
- Swagger API 문서: http://127.0.0.1:8000/docs

## 주요 API

| 기능 | 방식 | 주소 |
|---|---|---|
| 회원 전체 및 이름 검색 | GET | /api/users?name=검색어 |
| 회원 입력 | POST | /api/users |
| 회원 상세 조회 | GET | /api/users/{user_id} |
| 회원 수정 | PUT | /api/users/{user_id} |
| 회원 삭제 | DELETE | /api/users/{user_id} |
| 영화 전체 및 제목 검색 | GET | /api/movies?title=검색어 |
| 영화 입력 | POST | /api/movies |
| 영화 상세 및 평균 평점 | GET | /api/movies/{movie_id} |
| 영화 수정 | PUT | /api/movies/{movie_id} |
| 영화 삭제 | DELETE | /api/movies/{movie_id} |
| 전체 및 조건별 평점 조회 | GET | /api/ratings |
| 회원별 영화 평점 조회 | GET | /api/users/{user_id}/ratings |
| 평점 입력 | POST | /api/users/{user_id}/ratings |
| 평점 수정 | PUT | /api/users/{user_id}/ratings/{movie_id} |
| 평점 삭제 | DELETE | /api/users/{user_id}/ratings/{movie_id} |
| 회원별 추천 | GET | /api/recommend?user_id=1&limit=12 |

평점은 0점부터 5점까지 입력할 수 있습니다. 회원이나 영화를 삭제하면 연결된 평점도 외래키의 `ON DELETE CASCADE` 설정에 따라 함께 삭제됩니다.
