from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Movie, Rating
from ..schemas import MovieCreate, MovieOut, MovieStatsOut, MovieUpdate

router = APIRouter(prefix="/api/movies", tags=["movies"])


def find_movie(db: Session, movie_id: int) -> Movie:
    movie = db.get(Movie, movie_id)
    if movie is None:
        raise HTTPException(status_code=404, detail="영화를 찾을 수 없습니다.")
    return movie


@router.get("", response_model=List[MovieStatsOut])
def list_movies(skip: int = Query(default=0, ge=0), limit: int = Query(default=100, ge=1, le=500),
                title: str | None = Query(default=None), db: Session = Depends(get_db)):
    query = (
        db.query(Movie, func.avg(Rating.rating).label("average_rating"),
                 func.count(Rating.movie_id).label("rating_count"))
        .outerjoin(Rating, Rating.movie_id == Movie.id)
        .group_by(Movie.id)
    )
    if title:
        query = query.filter(Movie.title.ilike(f"%{title.strip()}%"))
    rows = query.order_by(Movie.id).offset(skip).limit(limit).all()
    return [
        {**MovieOut.model_validate(movie).model_dump(),
         "average_rating": round(float(average), 2) if average is not None else None,
         "rating_count": int(count)}
        for movie, average, count in rows
    ]


@router.post("", response_model=MovieOut, status_code=status.HTTP_201_CREATED)
def create_movie(payload: MovieCreate, db: Session = Depends(get_db)):
    movie = Movie(**payload.model_dump())
    db.add(movie)
    db.commit()
    db.refresh(movie)
    return movie


@router.get("/{movie_id}", response_model=MovieStatsOut)
def get_movie(movie_id: int, db: Session = Depends(get_db)):
    movie = find_movie(db, movie_id)
    average, count = db.query(func.avg(Rating.rating), func.count(Rating.movie_id)).filter(
        Rating.movie_id == movie_id).one()
    return {**MovieOut.model_validate(movie).model_dump(),
            "average_rating": round(float(average), 2) if average is not None else None,
            "rating_count": int(count)}


@router.put("/{movie_id}", response_model=MovieOut)
def update_movie(movie_id: int, payload: MovieUpdate, db: Session = Depends(get_db)):
    movie = find_movie(db, movie_id)
    for field, value in payload.model_dump().items():
        setattr(movie, field, value)
    db.commit()
    db.refresh(movie)
    return movie


@router.delete("/{movie_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_movie(movie_id: int, db: Session = Depends(get_db)):
    db.delete(find_movie(db, movie_id))
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
