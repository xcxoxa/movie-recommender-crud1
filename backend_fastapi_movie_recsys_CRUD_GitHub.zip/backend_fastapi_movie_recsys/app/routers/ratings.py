from typing import List

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Movie, Rating, User
from ..schemas import RatingDetailOut

router = APIRouter(prefix="/api/ratings", tags=["ratings"])


@router.get("", response_model=List[RatingDetailOut])
def list_ratings(user_id: int | None = Query(default=None, gt=0),
                 movie_id: int | None = Query(default=None, gt=0), db: Session = Depends(get_db)):
    query = (db.query(Rating, User.name, Movie.title)
             .join(User, User.id == Rating.user_id)
             .join(Movie, Movie.id == Rating.movie_id))
    if user_id is not None:
        query = query.filter(Rating.user_id == user_id)
    if movie_id is not None:
        query = query.filter(Rating.movie_id == movie_id)
    rows = query.order_by(Rating.user_id, Rating.movie_id).all()
    return [
        {"user_id": rating.user_id, "user_name": user_name, "movie_id": rating.movie_id,
         "movie_title": movie_title, "rating": rating.rating}
        for rating, user_name, movie_title in rows
    ]
