from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Movie, Rating, User
from ..schemas import RatingDetailOut, RatingIn, RatingOut, RatingUpdate, UserCreate, UserOut, UserUpdate

router = APIRouter(prefix="/api/users", tags=["users"])


def find_user(db: Session, user_id: int) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="회원을 찾을 수 없습니다.")
    return user


@router.get("", response_model=List[UserOut])
def list_users(name: str | None = Query(default=None), db: Session = Depends(get_db)):
    query = db.query(User)
    if name:
        query = query.filter(User.name.ilike(f"%{name.strip()}%"))
    return query.order_by(User.id).all()


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(payload: UserCreate, db: Session = Depends(get_db)):
    user = User(name=payload.name)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.get("/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Session = Depends(get_db)):
    return find_user(db, user_id)


@router.put("/{user_id}", response_model=UserOut)
def update_user(user_id: int, payload: UserUpdate, db: Session = Depends(get_db)):
    user = find_user(db, user_id)
    user.name = payload.name
    db.commit()
    db.refresh(user)
    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user(user_id: int, db: Session = Depends(get_db)):
    db.delete(find_user(db, user_id))
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/{user_id}/ratings", response_model=List[RatingDetailOut])
def get_ratings(user_id: int, db: Session = Depends(get_db)):
    find_user(db, user_id)
    rows = (
        db.query(Rating, User.name, Movie.title)
        .join(User, User.id == Rating.user_id)
        .join(Movie, Movie.id == Rating.movie_id)
        .filter(Rating.user_id == user_id)
        .order_by(Movie.id)
        .all()
    )
    return [
        {"user_id": rating.user_id, "user_name": user_name, "movie_id": rating.movie_id,
         "movie_title": movie_title, "rating": rating.rating}
        for rating, user_name, movie_title in rows
    ]


@router.post("/{user_id}/ratings", response_model=RatingOut, status_code=status.HTTP_201_CREATED)
def create_rating(user_id: int, payload: RatingIn, db: Session = Depends(get_db)):
    find_user(db, user_id)
    if db.get(Movie, payload.movie_id) is None:
        raise HTTPException(status_code=404, detail="영화를 찾을 수 없습니다.")
    if db.get(Rating, (user_id, payload.movie_id)):
        raise HTTPException(status_code=409, detail="이미 등록된 평점입니다. 수정 기능을 이용해 주세요.")
    rating = Rating(user_id=user_id, movie_id=payload.movie_id, rating=payload.rating)
    db.add(rating)
    db.commit()
    db.refresh(rating)
    return rating


@router.put("/{user_id}/ratings/{movie_id}", response_model=RatingOut)
def update_rating(user_id: int, movie_id: int, payload: RatingUpdate, db: Session = Depends(get_db)):
    rating = db.get(Rating, (user_id, movie_id))
    if rating is None:
        raise HTTPException(status_code=404, detail="평점을 찾을 수 없습니다.")
    rating.rating = payload.rating
    db.commit()
    db.refresh(rating)
    return rating


@router.delete("/{user_id}/ratings/{movie_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_rating(user_id: int, movie_id: int, db: Session = Depends(get_db)):
    rating = db.get(Rating, (user_id, movie_id))
    if rating is None:
        raise HTTPException(status_code=404, detail="평점을 찾을 수 없습니다.")
    db.delete(rating)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
