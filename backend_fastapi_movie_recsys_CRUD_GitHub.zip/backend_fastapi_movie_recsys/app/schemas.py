from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class UserCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("이름을 입력해 주세요.")
        return value


class UserUpdate(UserCreate):
    pass


class UserOut(ORMModel):
    id: int
    name: str


class MovieCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    genres: Optional[str] = Field(default=None, max_length=255)
    overview: Optional[str] = None
    year: Optional[int] = Field(default=None, ge=1888, le=2100)
    poster_url: Optional[str] = Field(default=None, max_length=500)
    popularity: float = Field(default=0, ge=0)

    @field_validator("title")
    @classmethod
    def clean_title(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("영화 제목을 입력해 주세요.")
        return value


class MovieUpdate(MovieCreate):
    pass


class MovieOut(ORMModel):
    id: int
    title: str
    genres: Optional[str] = None
    overview: Optional[str] = None
    year: Optional[int] = None
    poster_url: Optional[str] = None
    popularity: float = 0


class MovieStatsOut(MovieOut):
    average_rating: Optional[float] = None
    rating_count: int = 0


class RatingIn(BaseModel):
    movie_id: int = Field(gt=0)
    rating: float = Field(ge=0, le=5)


class RatingUpdate(BaseModel):
    rating: float = Field(ge=0, le=5)


class RatingOut(ORMModel):
    user_id: int
    movie_id: int
    rating: float


class RatingDetailOut(RatingOut):
    user_name: str
    movie_title: str


class RecommendationOut(BaseModel):
    movie: MovieOut
    score: float
