# React Movie Recommender CRUD

기존 프로젝트명을 유지하면서 회원, 영화, 평점 관리 화면을 추가한 React 프론트엔드입니다.

## 실행

```powershell
cd C:\bangminjung\04_react_fastapi_mysql\frontend_react_movie_recsys
npm install
npm run dev
```

브라우저에서 http://localhost:5173 을 엽니다. 백엔드는 먼저 8000번 포트에서 실행해야 합니다.

## 화면

- 회원 관리: 회원 입력, 이름 검색, 수정, 삭제
- 영화 관리: 영화 입력, 제목 검색, 수정, 삭제, 평균 평점과 평가 인원 조회
- 평점 관리: 회원과 영화 선택, 평점 입력, 회원별 조회, 수정, 삭제
- 영화 추천: 기존 콘텐츠 기반 추천 기능 유지
- 사용자 선택: 기존 사용자 선택 기능 유지
