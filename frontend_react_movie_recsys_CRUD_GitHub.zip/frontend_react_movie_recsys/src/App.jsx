import {NavLink,Navigate,Route,Routes} from 'react-router-dom'
import './styles.css'
import Login from './pages/Login'
import Movies from './pages/Movies'
import Ratings from './pages/Ratings'
import Recommendations from './pages/Recommendations'
import Users from './pages/Users'

export default function App(){
  return <div className="app-shell">
    <div className="ambient ambient-one" aria-hidden="true"></div><div className="ambient ambient-two" aria-hidden="true"></div>
    <header className="topbar"><div className="brand"><span className="brand-mark" aria-hidden="true">▶</span><div className="brand-copy"><h1>Movie Recommender</h1><p>React · FastAPI · MySQL 영화 추천 관리 시스템</p></div></div>
      <nav><NavLink to="/users">회원 관리</NavLink><NavLink to="/movies">영화 관리</NavLink><NavLink to="/ratings">평점 관리</NavLink><NavLink to="/recommendations">영화 추천</NavLink><NavLink to="/">사용자 선택</NavLink></nav>
    </header>
    <Routes><Route path="/" element={<Login/>}/><Route path="/users" element={<Users/>}/><Route path="/movies" element={<Movies/>}/><Route path="/ratings" element={<Ratings/>}/><Route path="/recommendations" element={<Recommendations/>}/><Route path="*" element={<Navigate to="/users" replace/>}/></Routes>
  </div>
}
