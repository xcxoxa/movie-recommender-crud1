import axios from 'axios'

const api = axios.create({baseURL: import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000', timeout: 10000})
export function errorMessage(error){const detail=error?.response?.data?.detail;if(Array.isArray(detail))return detail.map(item=>item.msg).join(', ');return detail||'서버 요청 중 오류가 발생했습니다.'}
export const fetchUsers=async(name='')=>(await api.get('/api/users',{params:{name:name||undefined}})).data
export const createUser=async(payload)=>(await api.post('/api/users',payload)).data
export const updateUser=async(id,payload)=>(await api.put(`/api/users/${id}`,payload)).data
export const deleteUser=async(id)=>api.delete(`/api/users/${id}`)
export const fetchMovies=async(title='')=>(await api.get('/api/movies',{params:{title:title||undefined,limit:500}})).data
export const createMovie=async(payload)=>(await api.post('/api/movies',payload)).data
export const updateMovie=async(id,payload)=>(await api.put(`/api/movies/${id}`,payload)).data
export const deleteMovie=async(id)=>api.delete(`/api/movies/${id}`)
export const fetchRatings=async(params={})=>(await api.get('/api/ratings',{params})).data
export const createRating=async(userId,payload)=>(await api.post(`/api/users/${userId}/ratings`,payload)).data
export const updateRating=async(userId,movieId,payload)=>(await api.put(`/api/users/${userId}/ratings/${movieId}`,payload)).data
export const deleteRating=async(userId,movieId)=>api.delete(`/api/users/${userId}/ratings/${movieId}`)
export const fetchRecommendations=async(userId,limit=12)=>(await api.get('/api/recommend',{params:{user_id:userId,limit}})).data
export default api
