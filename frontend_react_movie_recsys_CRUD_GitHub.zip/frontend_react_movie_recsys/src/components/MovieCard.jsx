import React from 'react'

export default function MovieCard({ movie, score }){
  return (
    <article className="movie-card">
      <img className="movie-poster" src={movie.poster_url} alt={movie.title} onError={(e)=>{e.currentTarget.style.display='none'}}/>
      <div className="movie-info">
        <h3>{movie.title}</h3>
        <div className="movie-meta">{movie.genres} {movie.year ? `• ${movie.year}` : ''}</div>
        {typeof score === 'number' && <div className="ai-score">AI SCORE {score.toFixed(3)}</div>}
        {movie.overview && <p className="movie-overview">{movie.overview}</p>}
      </div>
    </article>
  )
}
