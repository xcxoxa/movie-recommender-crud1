import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { fetchUsers } from '../api'

export default function Login(){
  const [users, setUsers] = useState([])
  const [selected, setSelected] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  useEffect(()=>{
    fetchUsers().then(setUsers).catch(()=>setError('회원 목록을 불러오지 못했습니다. 백엔드 실행 상태를 확인해 주세요.'))
  }, [])

  function submit(e){
    e.preventDefault()
    if(!selected) return
    sessionStorage.setItem('user_id', selected)
    navigate('/recommendations')
  }

  return (
    <main className="panel login-panel">
      <h2>추천 사용자 선택</h2>
      <p>회원을 선택하면 해당 회원의 영화 평점을 기준으로 추천합니다.</p>
      {error && <div className="message error">{error}</div>}
      <form onSubmit={submit} style={{display:'flex', gap:12, alignItems:'center'}}>
        <select value={selected} onChange={e=>setSelected(e.target.value)}>
          <option value="">회원을 선택하세요</option>
          {users.map(u => <option key={u.id} value={u.id}>{u.id}. {u.name}</option>)}
        </select>
        <button className="primary" type="submit">추천 보기</button>
      </form>
    </main>
  )
}
