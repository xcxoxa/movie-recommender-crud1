import {useEffect,useState} from 'react'
import {createMovie,deleteMovie,errorMessage,fetchMovies,updateMovie} from '../api'

const blank={title:'',genres:'',overview:'',year:'',poster_url:'',popularity:'0'}
export default function Movies(){
  const [movies,setMovies]=useState([]),[form,setForm]=useState(blank),[editing,setEditing]=useState(null),[search,setSearch]=useState(''),[message,setMessage]=useState(''),[error,setError]=useState('')
  async function load(term=search){try{setMovies(await fetchMovies(term));setError('')}catch(e){setError(errorMessage(e))}}
  useEffect(()=>{load('')},[])
  function change(e){setForm({...form,[e.target.name]:e.target.value})}
  function payload(){return {...form,year:form.year?Number(form.year):null,popularity:Number(form.popularity||0),poster_url:form.poster_url||null,genres:form.genres||null,overview:form.overview||null}}
  async function save(e){e.preventDefault();try{editing?await updateMovie(editing,payload()):await createMovie(payload());setMessage(editing?'영화가 수정되었습니다.':'영화가 등록되었습니다.');setEditing(null);setForm(blank);await load()}catch(e){setError(errorMessage(e))}}
  function edit(m){setEditing(m.id);setForm({title:m.title,genres:m.genres||'',overview:m.overview||'',year:m.year||'',poster_url:m.poster_url||'',popularity:m.popularity??0});scrollTo({top:0,behavior:'smooth'})}
  async function remove(m){if(!confirm(`${m.title} 영화와 관련 평점을 삭제할까요?`))return;try{await deleteMovie(m.id);setMessage('영화가 삭제되었습니다.');await load()}catch(e){setError(errorMessage(e))}}
  return <main className="panel"><div className="page-head"><div><h2>영화 CRUD 및 평균 평점</h2><p>영화 정보와 평점 통계를 함께 관리합니다.</p></div></div>
    {message&&<div className="message">{message}</div>}{error&&<div className="message error">{error}</div>}
    <form className="form-grid" onSubmit={save}><input name="title" value={form.title} onChange={change} placeholder="영화 제목" required/><input name="genres" value={form.genres} onChange={change} placeholder="장르"/><input name="year" type="number" min="1888" max="2100" value={form.year} onChange={change} placeholder="개봉 연도"/><input name="popularity" type="number" min="0" step="0.1" value={form.popularity} onChange={change} placeholder="인기도"/><input className="wide" name="poster_url" value={form.poster_url} onChange={change} placeholder="포스터 URL"/><textarea className="full" name="overview" value={form.overview} onChange={change} placeholder="영화 줄거리"/><div className="actions full"><button className="primary">{editing?'수정 저장':'영화 등록'}</button>{editing&&<button type="button" className="secondary" onClick={()=>{setEditing(null);setForm(blank)}}>취소</button>}</div></form>
    <form className="toolbar" onSubmit={e=>{e.preventDefault();load()}}><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="영화 제목 검색"/><button className="secondary">검색</button><button type="button" className="secondary" onClick={()=>{setSearch('');load('')}}>전체 조회</button></form>
    <div className="table-wrap"><table><thead><tr><th>번호</th><th>영화이름</th><th>장르</th><th>연도</th><th>평균 평점</th><th>평가 수</th><th>관리</th></tr></thead><tbody>{movies.map(m=><tr key={m.id}><td>{m.id}</td><td>{m.title}</td><td>{m.genres||'-'}</td><td>{m.year||'-'}</td><td className="stars">{m.average_rating==null?'평점 없음':`${m.average_rating.toFixed(2)} / 5`}</td><td className="stat">{m.rating_count}</td><td className="actions"><button className="secondary" onClick={()=>edit(m)}>수정</button><button className="danger" onClick={()=>remove(m)}>삭제</button></td></tr>)}</tbody></table>{!movies.length&&<div className="empty">조회된 영화가 없습니다.</div>}</div>
  </main>
}
