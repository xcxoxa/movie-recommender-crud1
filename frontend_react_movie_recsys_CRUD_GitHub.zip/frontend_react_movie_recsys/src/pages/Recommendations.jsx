import React, { useEffect, useState } from 'react'
import { fetchRecommendations } from '../api'
import MovieCard from '../components/MovieCard'

export default function Recommendations(){
  const [recs, setRecs] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const userId = sessionStorage.getItem('user_id')

  useEffect(()=>{
    async function run(){
      try {
        const data = await fetchRecommendations(userId, 12)
        setRecs(data)
      } catch (e) {
        console.error(e)
        setError('추천을 불러오지 못했습니다.')
      } finally {
        setLoading(false)
      }
    }
    if (userId) run()
  }, [userId])

  if(!userId) return <p>먼저 사용자 선택 화면에서 유저를 선택해 주세요.</p>
  if(loading) return <p>불러오는 중...</p>
  if(error) return <p>{error}</p>

  return (
    <main className="panel">
      <div className="page-head"><div><h2>회원별 영화 추천</h2><p>선택 회원번호 {userId}의 평점을 기준으로 계산한 결과입니다.</p></div></div>
      <div className="card-grid">
        {recs.map((r, idx) => (
          <MovieCard key={idx} movie={r.movie} score={r.score} />
        ))}
      </div>
    </main>
  )
}
