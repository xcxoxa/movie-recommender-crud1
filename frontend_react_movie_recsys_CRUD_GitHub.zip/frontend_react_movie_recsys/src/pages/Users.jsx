import {useEffect,useState} from 'react'
import {createUser,deleteUser,errorMessage,fetchUsers,updateUser} from '../api'

export default function Users(){
  const [users,setUsers]=useState([]),[name,setName]=useState(''),[search,setSearch]=useState(''),[editing,setEditing]=useState(null),[message,setMessage]=useState(''),[error,setError]=useState('')
  async function load(term=search){try{setUsers(await fetchUsers(term));setError('')}catch(e){setError(errorMessage(e))}}
  useEffect(()=>{load('')},[])
  async function save(e){e.preventDefault();try{editing?await updateUser(editing,{name}):await createUser({name});setMessage(editing?'회원 정보가 수정되었습니다.':'회원이 등록되었습니다.');setName('');setEditing(null);await load()}catch(e){setError(errorMessage(e))}}
  function edit(user){setEditing(user.id);setName(user.name);setMessage('')}
  async function remove(user){if(!confirm(`${user.name} 회원과 관련 평점을 삭제할까요?`))return;try{await deleteUser(user.id);setMessage('회원이 삭제되었습니다.');await load()}catch(e){setError(errorMessage(e))}}
  return <main className="panel"><div className="page-head"><div><h2>회원 CRUD</h2><p>회원 입력 조회 수정 삭제</p></div></div>
    {message&&<div className="message">{message}</div>}{error&&<div className="message error">{error}</div>}
    <form className="form-grid" onSubmit={save}><input className="wide" value={name} onChange={e=>setName(e.target.value)} placeholder="회원 이름" maxLength="100" required/><div className="actions"><button className="primary">{editing?'수정 저장':'회원 등록'}</button>{editing&&<button type="button" className="secondary" onClick={()=>{setEditing(null);setName('')}}>취소</button>}</div></form>
    <form className="toolbar" onSubmit={e=>{e.preventDefault();load()}}><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="회원 이름 검색"/><button className="secondary">검색</button><button type="button" className="secondary" onClick={()=>{setSearch('');load('')}}>전체 조회</button></form>
    <div className="table-wrap"><table><thead><tr><th>회원번호</th><th>회원이름</th><th>관리</th></tr></thead><tbody>{users.map(u=><tr key={u.id}><td>{u.id}</td><td>{u.name}</td><td className="actions"><button className="secondary" onClick={()=>edit(u)}>수정</button><button className="danger" onClick={()=>remove(u)}>삭제</button></td></tr>)}</tbody></table>{!users.length&&<div className="empty">조회된 회원이 없습니다.</div>}</div>
  </main>
}
